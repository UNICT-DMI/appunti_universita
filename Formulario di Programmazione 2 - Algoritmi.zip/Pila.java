public class Pila{
	private int top;		//indice per l'ultimo elem inserito
	private final int MAX;	//massimo contenuto di una pila
	private int elem[];		//array degli elementi della pila
	private static final int MAXDEFAULT = 10;

	public Pila(){
		this(MAXDEFAULT);
	}

	public Pila(int max){
		top = 0;
		MAX = max;
		elem = new int[MAX];
	}

	public boolean IsFull(){
		return (top == MAX);
	}

	public boolean IsEmpty(){
		return (top == 0);
	}
	
	public void Clear(){
		top = 0;
	}

	public boolean Push(int val){	//inserimento
		if (IsFull())
			return false;
		elem[top++] = val;
		return true;
	}
	
	public int Pop(){				//estrazione
		if (IsEmpty())
			return 0;
		return elem[--top];
	}
	
	public int TopElem(){			//restituisce il valore dell'elemento in cima
		if (IsEmpty())
			return 0;
		return elem[top-1];			//ritorna top-1 poich� l'array elem[] (come tutti gli array) inizia dall'indice 0, dove c'� il primo elemento inserito nella pila
	}

}
