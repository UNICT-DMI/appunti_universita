/*	FATTORIALE
	metodi iterativi e ricorsivi per il calcolo del fattoriale
*/

	public static int iterFactorial(int n){
		if(n<0)
			throw new IllegalArgumentException();
		else if (n==0) return 1;
			else{
				int p=1;
				for (int i=2; i<=n; i++)
					p=p*i;
				return p;
		}
	}

	public static int ricFactorial(int n){
		if(n<0)
			throw new IllegalArgumentException();
		else if (n==0) return 1;
			else
				return n * factorial(n-1);
	}

/*	ESPONENZIALE
	metodi iterativi e ricorsivi per il calcolo dell'esponenziale
*/

	public int ricEsp(int x,int y){
		if (y==0) return 1;
		else return x*esp(x,y-1);
	}

	public double iterEsp(int x, int y){
		if(y<0)
			throw new IllegalArgumentException();
		else{
			if(y==0) return 1;
			else{
				int ris=x;
				while (y>1){
					ris=ris*x;
					y--;
				}
		return ris;
	}
	
/*	INVERTI STRINGA
	Inversione di una stringa presa in input
	(Esempio di ricorsione non in coda, dove la chiamata al metodo stesso non � l�ultima azione compiuta)
*/

	public void reverse(){
		char ch = (char)System.in.read();
		if (ch != �\n�){
			reverse();
			System.out.print(ch);
		}
	}

/*	FIBONACCI
	metodi iterativi e ricorsivi per il calcolo della successione di Fibonacci
	(Esempio di ricorsione multipla)
*/

public static int ricFibonacci(int n){
	if(n<0)
		throw new IllegalArgumentException();
	else if (n<2) return n;
		else
			return fibonacci(n-2) + fibonacci(n-1);
}

public static int iterFibonacci(int n){
	if (n<2) return n;
	else{
		int i=2, tmp, current=1, last=0;
		for (;i<=n; ++i){
			tmp = current;
			current += last;
			last = tmp;
		}
	return current;
}

/*	RICORSIONI VARIE
	Altri esempi di ricorsione
*/

	//Massimo comune divisore
	public static int MCD (int x, int y){
		if (x==y) return x;
		else if (x>y) return MCD(x-y,y);
		else return MCD (x,y-x);
	}
	
	//Minimo comune multiplo
	public static int mcm(int x, int y){
		if (x==0 && y==0) return 0;
		else return (x*y)/(MCD(x,y));
	}
	
	//Soluzione dela torre di Hanoi
public class TowersOfHanoi{
	private int totalDisks;
	
	public TowersOfHanoi(int disks){
		totalDisks = disks;
	}
	
	public void solve(){
		moveTower(totalDisks, 1, 3, 2);
	}
	
	private void moveTower(int numDisks, int start, int end, int temp){
		if (numDisks == 1)
			move OneDisk(start, end);
		else{
			moveTower(numDisks-1, start, temp, end);
			moveOneDisk(start, end);
			moveTower(numDisks-1, temp, end, start);
		}
	}
	
	private void moveOneDisk(int start, int end){
		System.out.println("Sposta un disco da "+start+" a "+end);
	}
}