/*//////////////////////////
 	MECCANISMO TRY ... CATCH
*//////////////////////////

// PseudoCodice

try{
      fai qualcosa;
} catch (tipo-eccezione nome-eccezione){
      fai qualcosa per correggere o segnalare l'eccezzione;
}

//////////ESEMPIO//////////////////////////////////////
public int f1(int[] a, int n){
	throws ArrayIndexOutOfBoundsException;
   	return n*a[n+2]
}

//f1() ritorna l'elemento dell'array a[n+1]*n

public void f2(){
      int[]a={1,2,3,4,5};
      try{
		for (int i=0;i<a.lentgh;i++)
	      System.outprint(f1(a,i)+" ");
      } catch(ArrayIndexOutOfBoundsException e){
          System.out.println(�Eccezione catturata in f2()�);
       		throw e;
       	}
}

/*	f2() crea un array di 5 elementi e stampa il metodo f1(a,i)
	ma arrivato ad i=3 non potr� stampare a[5] perch� non rientra nell'array.
	Dunque il controllo del corpo del catch si accorge che � stato generata
	un'eccezione "ArrayIndexOutOfBoundsException" e la chiama "e", stampa il messaggio
	che l'eccessione � stata catturata (quindi non la risolve) e lo manda ad f1()
*/

 /*//////////////////////////
 	THROW E CATTURA DELLE ECCEZIONI
*//////////////////////////


class Eccezioni{

  void f() throws Exception{
		g();
   }
   
   void g() throws Exception{
		h();
   }
 
   void h()throws Exception {
       int x = 0;
       if (x==0)
         throw new Exception(�divisione per 0�);
       int y=2/x;
    }
 }
 
 /*	i metodi si richiamano a cascata indicando nei costruttori che potrebbero
 	esserci eccezioni. In questo caso solamente col throw stiamo lanciando l'eccezione
 	ma non la stiamo catturando, quindi essa si propaga e interrompe il programma
 */
 
 class Eccezioni{
  void f() throws Exception{
         g();
   }
   
   void g()throws Exception {
       h();
   }
   
   void h()throws Exception {
       int x =0;
       try{
             int y= 2/x;
       }catch(ArithmeticException ae){
			System.out.print(�errore!�)
       }
    }
}

/*	in questo caso l'eccezzione � catturata dal catch, il quale stamper� a
	console l'errore ma non lo far� propagare, e il programma continua a compilare
 */
 
 /*//////////////////////////
 	Esempio di interfaccia
*//////////////////////////

interface Nuotatore{
   public void nuota();
}

class Acquario{
   Nuotatore[] elementi = new Nuotatore[10];
   //metodi della classe
}

class Pesce implements Nuotatore{
   public void nuota(){
   	�
   	}
}

class Crostaceo{
	�
}

class Granchio extends Crostaceo implements Nuotatore{
    public void nuota(){
    	�
    }
}

/*	Le interfacce non si possono istanziare. Prendiamo l�esempio sopra:
	Nuotatore n = new Nuotatore();	NO
	Posso per� assegnare i tipi che sono stati implementati
	Nuotatore p = new Pesce();		SI
*/