/*	SWAP
	Per scambiare il valore di due elementi in un array
	serve un indice temporaneo
*/

void swap(int array[], int precedente, int successivo) {
	int tmp = array[precedente];
	array[precedente] = array[successivo];
	array[successivo] = tmp;
}

/*	SELECTION SORT
	L�algoritmo seleziona di volta in volta il record con
	chiave minima (oppure massima), spostandolo nella posizione corretta
*/

public void SelectionSort(int [] data) {
	int i,j,minimo;
	for (i = 0; i < data.length-1; i++) {
		for (j=i+1, minimo=i; j<data.length; j++)
			if (data[j]<data[minimo])
				minimo = j;
		swap(data,minimo,i);
	}
}

//complessit� #confronti 	= migliore O(n^2), medio O(n^2), peggiore O(n^2)
//complessit� #spostamenti 	= migliore O(1), medio O(n), peggiore O(n)

/*	INSERTION SORT
	Ogni elemento dell�array viene spostato in un sotto-array che viene ordinato,
	facendo poi shiftare il processo al numero successivo
*/

public void InsertionSort(int[] data) {
	int i, j,tmp;
	for (i = 1; i < data.length; i++) {
		tmp = data[i];
		for (j=i; (j>0)&&(tmp<data[j-1]); j--)
			data[j] = data[j-1];
		data[j] = tmp;
	}
}

//complessit� #confronti 	= migliore O(n), medio O(n^2), peggiore O(n^2)
//complessit� #spostamenti 	= migliore O(n), medio O(n^2), peggiore O(n^2)

/*	BUBBLE SORT
	Confronta elementi consecutivi (j e j-1) iniziando da destra,
	scambiandoli se non li trova in ordine. Al termine del primo
	ciclo viene cos� trovato il minimo, che galleggia in cima all�array.
	Al i-esimo passaggio viene trovato il i-esimo elemento pi� piccolo,
	posizionandolo all� i-esimo posto.
*/

public void BubbleSort(int [] data){
	for (int pass = 0; pass < data.length-1; pass++)
		for (i = 1; i<data.length;i++)
			if (data[i]<data[i-1])
				swap(data,i,i-1);
}
    
//complessit� #confronti 	= migliore O(n^2), medio O(n^2), peggiore O(n^2)
//complessit� #spostamenti 	= migliore O(1), medio O(n^2), peggiore O(n^2)