/*	IMPLEMENTAZIONE DI UN BST
	Un BST pu� essere implementato dinamicamente mediante una struttura
	in cui ogni nodo ha due riferimenti ai nodi figli
*/

//NODO di un BST di interi
public class NodoBST{
	protected int key;
	protected NodoBST left, right;	//figlio sinisto e figlio destro

	public NodoBST(){
		left = right = null;
	}
	
	public NodoBST(int val){
		this(val, null, null);

	public NodoBST(int val, NodoBST sinistro, NodoBST destro){
		key = val; left = sinistro; right = destro;				//riferimenti ai figli
	}
	
	public int visit(){			//questo metodo � da gestire, pu� ritornare la key, stamparla o altro a seconda dell'uso necessario
		return key;
	}
}

//BST di interi
public class BST{
	protected NodoBST root;

	public BST(){
		root = null;
	}
}

/*	ATTRAVERSAMENTO PREORDER
	- visitare la radice
	- attraversare ricorsivamente il sotto-albero sinistro della radice
	- attraversare ricorsivamente il sotto-albero destro della radice
*/

protected void ricPreorder(NodoBST p){
	if (p != null){
		p.visit();
		preorder(p.left);
		preorder(p.right);
	}
}

protected void iterPreorder(){
	NodoBST p = root;
	Pila aiuto = new Pila();
	if (p != null){
		aiuto.push(p);
		while (!aiuto.isEmpty()){
			p = (NodoBST) aiuto.pop();
			p.visit();
			if (p.right != null) aiuto.push(p.right);
			if (p.left != null) aiuto.push(p.left);
		}
	}
}

/*	ATTRAVERSAMENTO INORDER
	- attraversare ricorsivamente il sotto-albero sinistro della radice
	- visitare la radice
	- attraversare ricorsivamente il sotto-albero destro della radice
*/

protected void ricInorder(NodoBST p){
	if (p != null){
		inorder(p.left);
		p.visit();
		inorder(p.right);
	}
}

protected void iterInorder(){
	NodoBST p = root;
	Pila aiuto = new Pila();
	while (p != null){
		while (p != null){ 	
			if (p.right != null) aiuto.push(p.right);	// impila figlio dx se esiste, e il nodo stesso procedendo verso sx
			aiuto.push(p);
			p = p.left;
		}
		p = (NodoBST) aiuto.pop();							// estrai un nodo senza figlio sinistro
		while (!aiuto.isEmpty() && p.right == null){		//visita nodo e tutti quelli senza figlio dx
			p.visit();
			p = (NodoBST) aiuto.pop();
		}
		p.visit();											// visita anche il primo nodo con un figlio dx
		if (!aiuto.isEmpty())
			p = (NodoBST) aiuto.pop();
		else p = null;
	}
}

/*	ATTRAVERSAMENTO POSTORDER
	- attraversare ricorsivamente il sotto-albero sinistro della radice
	- attraversare ricorsivamente il sotto-albero destro della radice
	- visitare la radice	
*/

protected void ricPostorder(NodoBST p){
	if (p != null){
		postorder(p.left);
		postorder(p.right);
		p.visit();
	}
}

protected void iterPostorder(){
	NodoBST p = root, q = root;
	Pila aiuto = new Pila();
	while (p != null){
		for (; p.left != null; p = p.left) aiuto.push(p);
		while (p != null && (p.right == null || p.right == q)){
			p.visit();
			q = p;
			if (aiuto.isEmpty()) return;
			p = (NodoBST) aiuto.pop();
		}
		aiuto.push(p);
		p = p.right;
	}
}

/*	RICERCA SU UN BST
	L�algoritmo per decidere se una chiave si trova in un BST avviene
	attraverso i seguenti controlli
*/

public NodoBST ricerca (NodoBST p, int val){
	while (p != null)						//Se il BST � vuoto restituisce null
		if (val == p.key) return p;			//Se la chiave coincide con l�etichetta della radice, si restituisce la radice
		else if (val < p.key) p = p.left;	//Se la chiave � minore dell�etichetta della radice, si esegue l�algoritmo sul sotto-albero sinistro della radice
		else p = p.right;					//Se la chiave � maggiore dell�etichetta della radice, si esegue l�algoritmo sul sotto-albero destro della radice
	return null;
}

/*	INSERIMENTO IN UN BST
	Inserisce un nuovo nodo in base al valore di esso
*/

public boolean inserisci (int val){
	if (root == null)
		root = new NodoBST(val);				//Se il BST � vuoto, la chiave diventa la radice
	else{
		NodoBST p = root, prev = null;
		while (p != null){						//Ricerca della chiave, scorrimento dell'albero
			if (val == p.key)
				return false; 					//Ritorna false se la chiave � gi� presente
			prev = p;
			if (val < p.key)
				p = p.left;
			else
				p = p.right;
			}
		if (val < prev.key)						//Si determina la foglia che pu� essere il padre del nuovo nodo
			prev.left = new NodoBST(val);		//Si innesta il nuovo nodo come figlio della foglia trovata
		else
			prev.right = new NodoBST(val);
		}
	return true;
}

/*	CANCELLAZIONE DA UN BST
	Per cancellare da un BST una certa chiave, mantenendo le propriet� di BST, abbiamo 4 casi:
	0. Si ricerca la chiave, se non si trova si restituisce false
	1. Se la chiave si trova in una foglia, si metta a null il riferimento del nodo padre alla foglia
	2. Se la chiave si trova in un nodo avente un solo sotto-albero, si faccia puntare al figlio il riferimento del nodo padre al nodo
	3. Se la chiave si trova in un nodo con due sotto-alberi, si esegua la fusione dei due sotto-alberi o la sostituzione della chiave.
*/

public int cancella (int val){
	NodoBST nodo, p = root, prev = null;
	while (p != null && p.key != val){
		prev = p;
		if (val < p.key) p = p.left;
		else p = p.right;
	}
	nodo = p;
	if (p != null && p.key == val){
		if (nodo.right == null) nodo = nodo.left; 		//passi 1 e 2
		else if (nodo.left == null) nodo = nodo.right;
		else	fondiSottoAlberi() 						//passo 3
				sostituisciChiave()						//in alternativa al precedente
		if (p == root) root = nodo; 					//continua
		else if (prev.left == p) prev.left = nodo; 		//passi 1 e 2
		else prev.right = nodo; 
		return 0; 										//cancellazione effettuata
	}
	else if (root != null)								//casi limite
		return �1;										//chiave non presente nel BST
	else
		return �2; 										//BST vuoto
} 	


//FUZIONE DI DUE SOTTOALBERI
{NodoBST tmp = nodo.left;
	while (tmp.right != null)
		tmp = tmp.right;
	tmp.right = nodo.right;
	nodo = nodo.left;
}

//SOSTITUZIONE DI DUE SOTTOALBERI
{ 	NodoBST tmp = nodo.left;
	NodoBST previous = nodo;
	while (tmp.right != null)
	{ 	previous = tmp;
		tmp = tmp.right;
	}
	nodo.key = tmp.key;
	if (previous == nodo)
		previous.left = tmp.left;
	else
		previous.right = tmp.left;
}

/* OPERAZIONI VARIE */
protected void LetturaLivelli(){
	NodoBST p = root;
	Coda aiuto = new Coda();
	if (p != null){
		aiuto.Enqueue(p);
		while (!aiuto.isEmpty()){
			p = (IntBSTNodo) aiuto.Dequeue();
			p.visit();
			if (p.left != null) aiuto.Enqueue(p.left);
			if (p.right != null) aiuto.Enqueue(p.right);
		}
	}
}