/*	FILEINPUSTREAM
	Lettura da un file binario con il FileInputStream
*/

import java.io.*;
public class LetturaDaFileBinario {
	public static void main(String args[]){
		FileInputStream file = null;
		try {
			file = new FileInputStream(args[0]);		//args[0] potrebbe essere un percorso di un file nel PC
		} catch(FileNotFoundException e){
			System.out.println("File non trovato");
			System.exit(1);
		}
		try {											//Inizio fase di lettura e stampa su console del carattere letto
			int x;
			int n = 0;
			while ((x = file.read())>=0){				//quando lo stream termina, read() restituisce -1 ed esce dal while
				System.out.print(" " + x);
				n++;
			}
			System.out.println("Totale byte: " + n);
			} catch(IOException ex){
				System.out.println("Errore di input");
				System.exit(2);
			}
	}
}

/*	FILEOUTPUTSTREAM
	Scrittura su un file binario con il FileOutputStream
*/

import java.io.*;
public class ScritturaSuFileBinario {
	public static void main(String args[]){
		FileOutputStream file = null;
		try {
			file = new FileOutputStream(args[0]);
		}catch(FileNotFoundException e){
			System.out.println("Imposs. aprire file");
			System.exit(1);
		}
		try {											//fase di scrittura
			for (int x=0; x<10; x+=3) {
				System.out.println("Scrittura di " + x);
				file.write(x);
				}
			} catch(IOException ex){
				System.out.println("Errore di output");
				System.exit(2);
			}
	}
}

/*	DATAINPUTSTREAM
	FileInpuStreamReader legge solo byte, dobbiamo incapsularlo dentro lo steam DataInputStream
	per leggere float, int, double, boolean
*/

import java.io.*;
public class LetturaTipi {
	public static void main(String args[]){
		FileInputStream fin = null;
		try {
			fin = new FileInputStream("Prova.dat");
		}catch(FileNotFoundException e){
			System.out.println("File non trovato");
			System.exit(3);
		}
		DataInputStream is = new DataInputStream(fin);		//Creazione del DataInputStream con argomento il FileInputStream
		float f2; char c2; boolean b2; double d2; int i2;
		try {
			f2 = is.readFloat(); b2 = is.readBoolean();
			d2 = is.readDouble(); c2 = is.readChar();
			i2 = is.readInt();
			is.close();
			System.out.println(f2 + ", " + b2 + ", "+ d2 + ", " + c2 + ", " + i2);
		} catch (IOException e){
			System.out.println("Errore di input");
			System.exit(4);
	}
}

/*	DATAOUTPUTSTREAM
	Stessa procedura dell'input per l'incapsulamento
*/
import java.io.*;
public class Scrittura Tipi {
	public static void main(String args[]){
		FileOutputStream fs = null;
		try {
			fs = new FileOutputStream("Prova.dat");
		}catch(IOException e){
			System.out.println("Apertura fallita");
			System.exit(1);
		}
		DataOutputStream os = new DataOutputStream(fs);
		float f1 = 3.1415F; char c1 = 'X';
		boolean b1 = true; double d1 = 1.4142;
		try {
			os.writeFloat(f1); os.writeBoolean(b1);
			os.writeDouble(d1); os.writeChar(c1);
			os.writeInt(12); os.close();
		} catch (IOException e){
			System.out.println("Scrittura fallita");
			System.exit(2);
		}
	}
}

/*	CHARACTERSTREAM
	Lettura da testo UNICODE
*/

import java.io.*;
public class LetturaDaFileDiTesto {
	public static void main(String args[]){
		FileReader r = null;
		try {
			r = new FileReader(args[0]);
		}catch(FileNotFoundException e){
			System.out.println("File non trovato");
			System.exit(1);
		}
		try {
			int n=0, x;
			while ((x = r.read())>=0) {
				char ch = (char) x;
				System.out.print(" " + ch); n++;	//Cast esplicito da int a char - Ma solo se � stato davvero letto un carattere (cio� se non � stato letto -1)
			}
			System.out.println("\nTotale caratteri: " + n);
		} catch(IOException ex){
			System.out.println("Errore di input");
			System.exit(2);
		}
	}
}

/*	SYSTEM.IN
	Essa � interpretata come un Reader incapsulato dentro un InputStreamReader
	il quale a sa volta � incapsulato dentro un lettore Bufferizzato
*/

import java.io.*;
public class SistemDentro {
	public static void main(String[] args){
		BufferedReader console = new BufferedReader (new InputStreamReader (System.in));
		System.out.println("Inserisci una riga di testo");
	try{
		String str = console.readLine();
		} catch (IOException e){
			System.out.println(e);
			System.exit(1);
		}
	}
}

/*	CONSOLEREADER
	Racchiude tutti i termini e i metodi della classe System per quanto riguarda l�input e l�output di dati	
*/

import java.io.*;
public class LettoreC{
	private BufferedReader reader;

	public LettoreC(){
		reader=new BufferedReader(new InputStreamReader (System.in));
	}
	
	public String readLine(){				//leggi una stringa
		String inputLine="";
		try{
			inputLine = reader.readLine();
		}catch(IOException e){
			System.out.println(e);
			System.exit(1);
		}
	return inputLine;
	}
	
	public int readInt (){
		String inputString = readLine();
		int n = Integer.parseInt(inputString);
		return n;
	}

	public double readDouble (){
		String inputString = readLine();
		double x = Double.parseDouble(inputString);
	return x;
	}
	
	public static void main (String [] args){
		LettoreC lettore = new LettoreC();
		System.out.println("come ti chiami?");
		String x = lettore.readLine();
		System.out.println("ciao "+x+", quanti anni hai?");
		int eta = lettore.readInt();
		System.out.println(eta <10? "solo "+eta+" anni? che piccolo!":eta+" anni? sei grande!");
	}
}

/*	LETTURA E SCRITTURA SU FILE
	Insieme delle classi di Java.IO per leggere e scrivere dati su file
*/

public class LetturaScritturaFile{ 
	public static void main (String [] args){
		int n;
		ConsoleReader console = new ConsoleReader(); 
		System.out.print("inserisci il nome del file di input : ");
		String FileIn = console.readLine();
		System.out.print("inserisci il nome del file di output : "); 
		String FileOut = console.readLine(); 
		try {
			FileReader lettore = new FileReader(FileIn);
			FileWriter scrittore = new FileWriter(FileOut); 
			while ((n=lettore.read()) !=-1){
				scrittore.write((char)n);
			} 
			lettore.close(); 
			scrittore.close(); 
		} 
		catch(FileNotFoundException e){
			System.out.println(e); 
			System.exit(1); 
		} 
		catch(IOException e){
			System.out.println(e);
			System.exit(1); 
		} 
	} 
}