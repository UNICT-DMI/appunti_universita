/*	SHELL SORT
	Ordina prima porzioni del sotto-array, e poi l'intero array originale
*/

void ShellSort (int [] data) {
	int i, j, k, h, hContatore, tmp, incrementi[] = new int[20];
	for (h = 1, i = 0; h < data.length; i++) {				// crea il numero corretto di incrementi h in base alla formula generale
		incrementi[i] = h;
		h = 3*h + 1;
	}
	for (i--; i >= 0; i--) {								// itera per il numero dei diversi incrementi h
		h = incrementi[i];
		for (hContatore = h; hContatore < 2*h; hContatore++) {		// itera per il numero di sottoarray ordinati-h nel passo i-mo
			for (j = hContatore; j < data.length; ) {				// ordina per insertion sort il sottoarray contenente ogni h-mo elemento dell� array �data�
			tmp = data[j];
			k = j;
			while ((k-h>=0) && (tmp<data[k-h])){
				data[k] = data[k-h];
				k -= h;
			}
			data[k] = tmp;
			j += h;
			}
		}
	}
}

/*	QUICK SORT
	Viene preso un elemento di riferimento, detto pivot, utilizzato per il confronto con gli altri elementi.
	L�array viene suddiviso in 2 sottoarray:
	- il primo contiene elementi minori (o uguali) del pivot
	- il secondo contiene elementi maggiori (o uguali) al pivot.
	Nella posizione centrale viene posto l�elemento pivot. 
	Si procede quindi in maniera ricorsiva a riordinare i due sottoarray.
*/

public void QuickSort(int[] data, int first, int last) {
	int lower = first + 1, upper = last, pivot = data[first];
	while (lower <= upper) {
		while (data[lower]<pivot)
			lower++;
		while (pivot<data[upper])
			upper--;
		if (lower < upper)
			swap(data,lower++,upper--);
		else lower++;
	}
swap(data,upper,first);
	if (first < upper-1)
		QuickSort(data,first,upper-1);
	if (upper+1 < last)
		QuickSort(data,upper+1,last);
}

//complessit� #confronti = migliore O(n lg n), medio O(n lg n), peggiore O(n^2)

/*	MERGE SORT
	E� un algoritmo che permette il riordino di un array
	mediante la chiamata ricorsiva della procedura su due
	met� dell�array da riordinare, seguite da un algoritmo
	di merging.
*/

void MergeSort(int [] data, int first, int last) {
	if (first < last) {
		int mid = (first + last) / 2;
		MergeSort(data, first, mid);
		MergeSort(data, mid+1, last);
		merge(data, first, last);
	}
}

int[] temp; // usato da merge();
	void merge(int[] data, int first, int last) {
		int mid = (first + last) / 2;
		int i1 = 0, i2 = first, i3 = mid + 1;
		while (i2 <= mid && i3 <= last)
			if (data[i2]<data[i3])
				temp[i1++] = data[i2++];
			else temp[i1++] = data[i3++];
		while (i2 <= mid)
			temp[i1++] = data[i2++];
		while (i3 <= last)
			temp[i1++] = data[i3++];
		for (i1 = 0, i2 = first; i2 <= last;
			data[i2++] = temp[i1++]);
}

void MergeSort(int[] data) {		// per occultare i limiti dell'array
	temp = new int [data.length];
	MergeSort(data,0,data.length-1);
}

//complessit� #confronti 	= migliore O(n lg n), medio O(n lg n), peggiore O(n lg n)
//complessit� #spostamenti 	= migliore O(n lg n), medio O(n lg n), peggiore O(n lg n)