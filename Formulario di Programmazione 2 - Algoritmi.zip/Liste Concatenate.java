/*	NODO
	Struttura di un Nodo della lista semplice
*/

class Nodo{
	private int info;		//valore del nodo
	private Nodo next;		//riferimento al prossimo nodo

	public Nodo(int val){
		this(val, null); 
	}
	
	public Nodo (int val, Nodo n){
		info = val;
		next = n;
	}

	public void setInfo(int val){
		info = val;
	}

	public int getInfo(){
		return info;
	}

	public void setNext(Nodo n){
		next = n;
	}

	public Nodo getNext(){
	return next;
	}
}

/*	NODO AUSILIARIO
	Per evitare di scrivere
	((head.getNext()).getNext).setNext(new Nodo(99));
	si crea un nodo ausiliaro a cui viene assegnato un nodo a noi interessato
*/

Nodo head = new Nodo(13);
Nodo aux = head;
aux.setNext(new Nodo(16));
aux = aux.getNext();
aux.setNext(new Nodo(18));

/*	LISTA CONCATENATA
	Gli elementi vengono aggiunti dinamicamente solo quando � necessario.
	Ogni elemento contiene un riferimento all�elemento successivo.
	Serve anche un identificatore esterno (aux) per tener traccia della lista.
*/

class Lista{
	private Nodo head;

	public Lista(){
		head = null;					//in caso di lista vuota
	}

	public void InsertHead(int val){
		head = new Nodo(val,head);
	}
	
	public boolean IsEmpty(){			//controlla se la lista � vuota
		return (head == null ? true : false);
	}

	public void InsertTail(int val){
		if (IsEmpty())
			head = new Nodo(val);		//se la lista � vuota inserisci il Nodo in testa
		else{
			Nodo aux = head;
			for( ; aux.next != null; aux = aux.next);		//scorrimento lista, porta aux all'ultimo nodo
			aux.next = new Nodo(val);
		}
	}
	
	public void InsertOrdered(int val){
		if (IsEmpty())
			head = new Nodo(val);
		else
			if( head.info > val)			//se il valore della testa � maggiore di val...
				head = new Nodo(val,head);	//..il Nodo con val diventa la nuova testa
			else{
				Nodo aux = head;
				for(;(aux.next!=null) && (aux.next.info<val);aux=aux.next);	//scorri fino a quando la lista finisce && valore di aux � minore di val
				aux.next = new Nodo(val,aux.next);
			}
	}
	
	public Nodo SearchOrd(int key){
		Nodo aux = head;
		for( ; (aux != null) && (aux.info < key); aux = aux.next);		//ricerca la lista � in ordine crescente, per il decrescente basta mettere >
		if((aux != null) && (aux.info == key))
			return aux;
		return null;
		}
		
	public Nodo Search(int key){
		Nodo aux = head;
		for(; (aux != null) && (aux.info != key); aux = aux.next); //la lista scorre fino a quando aux.info == key, o aux.info == null, in quest'ultimo caso la chiave non esiste nella lista
		return aux;
	}
	
	public int DeleteHead(){
		if(IsEmpty())
			return 0;
		else{
			Nodo aux = head;
			head = head.next;	//la nuova testa sar� il vecchio secondo nodo della lista
			return aux.info;
		}
	}
	
	public int DeleteTail(){
		if (IsEmpty())
			return 0;
		else{
			Nodo aux = head;
			Nodo prev = null;	//� un altro ausiliare ma per il nodo precedente
			for( ; aux.next != null; prev = aux, aux = aux.next);	//scorre la lista assegnando 2 ausiliari
			if(prev == null) //se prev == null vuol dire che abbiamo solo un elemento nella lista
				head = null;
			else
				prev.next = null; //dato che prev � il penultimo, prev.next � l'ultimo � viene cancellato
			return aux.info;
			}
	}
	
	public Nodo DeleteKey(int key){
		if (IsEmpty())
			return null;
		else{
			Nodo aux = head;
			Nodo prev = null;
			for(; (aux != null) && (aux.info != key); prev = aux, aux = aux.next);
			if(aux != null)
				if(prev == null)
					head = head.next;
				else
					prev.next = aux.next;	//unisci il riferimento del precedente del nodo A al successivo del nodo A
			return aux;
		}
	}
}

/*	NODO DOPPIO
	Struttura di un Nodo della lista doppiamente concatenata
*/

public class NodoDbl{
	public int info;
	public NodoDbl next, prev;	//riferimento al successivo e al precedente

	public NodoDbl(int val){
		this(val, null, null);
	}

	public NodoDbl(int val, NodoDbl n, NodoDbl p){
		info = val;
		next = n;
		prev = p;
	}
}

/*	LISTA DOPPIAMENTE CONCATENATA
 	Lista che permette di scorre sia dalla testa che dalla coda.
 	A tale scopo sono necessari due riferimenti, uno all�oggetto precedente e l�altro al successivo. 
*/

public class ListaDbl{
	private NodoDbl head;
	private NodoDbl tail;	//tail � usato per poter scorrere la lista anche al contrario

	public ListaDbl(){
		head = tail = null;
	}

	public boolean IsEmpty(){
		return head == null;
	}
	
	public void InsertHead(int val){
	if ( IsEmpty() )
	head = tail = new NodoDbl(val);
	else{
		head = new NodoDbl(val,head,null);
		head.next.prev = head;		//sistemazione del riferimento al nodo precedente della vecchia testa all'attuale testa
	}
}

	public void InsertTail(int val){
		if ( IsEmpty() )
		head = tail = new NodoDbl(val);
		else{
			tail = new NodoDbl(val,null,tail);
			tail.prev.next = tail;		//sistemazione del riferimento al nodo successivo della vecchia coda all'attuale coda
		}
	}

	public void InsertOrdered(int val){
		if (IsEmpty())
			head = tail = new NodoDbl(val);
		else
			if(head.info >= val)	//se l'elemento da inserire � il primo
				InsertHead(val);
			else{
				NodoDbl aux= head;
				for(; (aux!=null) && (aux.info<val); aux=aux.next);	//scorri la lista
				if (aux == null)
					InsertTail(val);	//se l'elemento da inserire � l'ultimo
				else{					//se l'elemento da inserire � nel mezzo...
					aux.prev = new NodoDbl(val,aux,aux.prev);	//...inserisci un nuovo nodo col riferimento al nodo successivo della lista e a quello precedente
					aux.prev.prev.next = aux.prev;	//sistemazione del riferimento al nodo successivo del nodo precedente al precedente del nodo da inserire al nodo da inserire
				}
			}
	}

	public NodoDbl SearchOrd(int key){
	NodoDbl aux = head;
	for(; (aux != null) && (aux.info < key); aux = aux.next);
	if((aux != null) && (aux.info == key))
		return aux;
	return null;
}

	public NodoDbl Search(int key){
		NodoDbl aux = head;
		for(; (aux != null) && (aux.info != key); aux = aux.next);
		return aux;
	}
	
	public int DeleteHead(){
	if(IsEmpty())
		return 0;
	else{
		NodoDbl aux = head;
		if (head == tail)
			head = tail = null;
			else{
				head = head.next;
				head.prev = null;
			}
		return aux.info;
	}
}

	public int DeleteTail(){
		if(IsEmpty())
			return 0;
		else{
			NodoDbl aux = tail;
			if (head == tail)
				head = tail = null;
			else{
				tail = tail.prev;
				tail.next = null;
			}
			return aux.info;
		}
	}
	
	public NodoDbl DeleteKey(int key){
		NodoDbl aux = head;
		for(;(aux!=null) && (aux.info!=key); aux=aux.next);
			if (aux != null)				// � stato trovato un elemento
				if(aux.prev == null){		// � la testa
					if (head == tail)		// un solo elemento nella lista
						head = tail = null;
					else{
						head = head.next;
						head.prev = null;
					}
				}
				else{
					if (aux == tail){
						tail = tail.prev;	// � la coda
						tail.next = null;
					}
					else{					// � un elemento nel mezzo
						aux.prev.next = aux.next;
						aux.next.prev = aux.prev;
					}
				}
		return aux;
	}
}